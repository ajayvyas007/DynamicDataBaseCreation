package com.ajayvyas.dynamdb.library;

/**
 * Created by ajay on 1/4/17.
 */

public class Config {
    /*
   * Declaire all api here
   * */
    public static final String APP_SECEMA ="http://sc.productrx.com/public/schema/survey";
    public static final String SUBMIT_DATA="http://sc.productrx.com/public/survey";
    public static final String GET_DATA="http://sc.productrx.com/public/survey/2017-03-29";
}
